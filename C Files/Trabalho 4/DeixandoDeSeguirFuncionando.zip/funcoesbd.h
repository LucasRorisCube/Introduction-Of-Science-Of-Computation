void Inicializar(int *NumUsuarios,FILE *Usuarios,dados *usuario,FILE *ArquivoPosts,dadosPosts *Posts,int *NumPosts);
void Salvar(int *NumUsuarios,FILE *Usuarios,dados *usuario,FILE *ArquivoPosts,dadosPosts *Posts,int *NumPosts);
void Terminar(int *NumUsuarios,FILE *Usuarios,dados *usuario,FILE *ArquivoPosts,dadosPosts *Posts,int *NumPosts);
int VerificarExistencia(char nick[40],dados *usuario,int *NumUsuarios);
