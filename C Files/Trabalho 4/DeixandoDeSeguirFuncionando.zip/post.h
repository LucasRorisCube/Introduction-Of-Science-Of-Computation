void AdicionarPost(dadosPosts *Posts,int *NumPosts,dados *usuario,int r);
void RemoverPost(dadosPosts *Posts,int *NumPosts,dados *usuario,int r,int x,int chave);
