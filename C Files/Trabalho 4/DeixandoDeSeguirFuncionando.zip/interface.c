#include <stdio.h>

#define TAMNOME 40

void menuSLogin() {
	printf("Bem vindo à Rede Social!!!\n\nVamos começar? \n\n");
	printf("Para iniciar sua navegação, escolha uma opção:\n");
	printf("1: para adicionar um novo usuário;\n");
	printf("2: para remover um usuário;\n");
	printf("3: para consultar um usuário;\n");
	printf("4: para fazer Login;\n");
	printf("7: se deseja sair.\n\n");
	printf("Após escolher sua opção, pressione Enter para prosseguir.\n\n");
}

void menuCLogin(char usuario[TAMNOME]) {
	/*int r = 0;
	while(usuario[r++] != '\0');
	usuario[r-2] = '\0';	
	printf("Olá, %s!\n\nComo têm sido?\n\n", usuario);*/
        printf("Para navegar, escolha uma opção:\n");
	printf("1: para fazer um post;\n");
	printf("2: para remover um post;\n");
	printf("3: para seguir algum usuário;\n");
}
