void Inicializar(int *NumUsuarios,FILE *Usuarios,dados *usuario,FILE *ArquivoPosts,dadosPosts *Posts,int *NumPosts);
void Salvar(int *NumUsuarios,FILE *Usuarios,dados *usuario,FILE *ArquivoPosts,dadosPosts *Posts,int *NumPosts);
void Terminar(int *NumUsuarios,FILE *Usuarios,dados *usuario,FILE *ArquivoPosts,dadosPosts *Posts,int *NumPosts);
int VerificarExistencia(char nick[40],dados *usuario,int *NumUsuarios);
void MostrarPostsUser(dadosPosts *Posts, dados *usuario, int r, int *NumPosts);
void VerificarAlocacao(void *ponteiro);
void MostrarInformacoes(int *NumUsuarios,dadosPosts *Posts,dados *usuario,int *NumPosts);
void ZerarRedeSocial(FILE *Usuarios,FILE *ArquivoPosts);