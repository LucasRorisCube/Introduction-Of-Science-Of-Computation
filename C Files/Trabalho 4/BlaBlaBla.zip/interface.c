#include <stdio.h>

#define TAMNOME 40

//printa o menu de administrador (sem ter feito login)
void menuSLogin() {
  printf("---------------------------------------------------------\n\n");
  printf("Para navegar, escolha uma opcao:\n\n");
  printf("1: para adicionar um novo usuario;\n");
  printf("2: para remover um usuario;\n");
  printf("3: para consultar um usuario;\n");
  printf("4: para fazer Login;\n");
  printf("5: para mostrar todos os posts;\n");
  printf("6: para zerar Bla Bla Bla;\n");
  printf("7: para listar usuarios cadastrados e suas informacoes;\n");
  printf("8: para apresentar informacoes da Bla Bla Bla;\n");
  printf("9: para sair.\n\n");
  printf("Apos escolher sua opcao, pressione Enter para prosseguir.\n\n");
  printf("---------------------------------------------------------\n\n");
}

//printa o menu de usuario (com login feito)
void menuCLogin() {
  printf("----------------------------------------------------\n\n");
  printf("Para navegar, escolha uma opcao:\n");
  printf("1: para fazer um post;\n");
  printf("2: para remover um post;\n");
  printf("3: para seguir algum usuario;\n");
  printf("4: para deixar de seguir algum usuario;\n");
  printf("5: para ver as postagens das pessoas que voce segue;\n");
  printf("6: para listar seus seguidores;\n");
  printf("7: para ver quem voce esta seguindo;\n");
  printf("8: para mostrar suas postagens;\n");
  printf("9: para mostrar suas informacoes;\n");
  printf("10: para voltar ao menu de administrador.\n\n");
  printf("----------------------------------------------------\n\n");
}
