void VerificarAlocacaoInt(int *ponteiro);
void VerificarAlocacaoChar(char *ponteiro);
void VerificarAlocacao_Char(char* *ponteiro);
void VerificarAlocacaoDados(dados *ponteiro);
void VerificarAlocacaoDadosPosts(dadosPosts *ponteiro);