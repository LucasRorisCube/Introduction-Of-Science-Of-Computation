void InserirUsuario(dados *usuario,int *NumUsuarios);
void RemoverUsuario(dados *usuario,int *NumUsuarios, dadosPosts *Posts,int *NumPosts);
void Seguir(dados *usuario,int r,int *NumUsuarios);
void DeixarSeguir(dados *usuario,int r,int *NumUsuarios);