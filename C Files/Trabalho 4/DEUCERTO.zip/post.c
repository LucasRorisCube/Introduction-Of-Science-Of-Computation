#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "struct.h"

#define TAMNOME 40

void AdicionarPost(dadosPosts *Posts,int *NumPosts,dados *usuario,int r){
  printf("Digite o que deseja publicar: ");
  setbuf(stdin,NULL);
  
  fgets(Posts[*NumPosts].Post,130,stdin);
  strcpy(Posts[*NumPosts].nick,usuario[r].nick);
  printf("%s",Posts[*NumPosts].Post);
  usuario[r].NPosts = usuario[r].NPosts + 1;
  *NumPosts = *NumPosts + 1;
}

void RemoverPost(dadosPosts *Posts,int *NumPosts,dados *usuario,int r,int x,int chave){
  setbuf(stdin,NULL);
  int aux = 0;
  for(int i = 0;i<*NumPosts;i++){
    if(strcmp(usuario[r].nick,Posts[i].nick) == 0){
      printf("%d - %s",aux,Posts[i].Post);
      aux++;
    }
  }
  *NumPosts = *NumPosts - 1;
  if(chave == 0){
    scanf("%d",&x);
  }
  int flag = 0;
  for(int i = 0;i<*NumPosts;i++){
    if(strcmp(usuario[r].nick,Posts[i].nick) == 0){
      flag++;
    }
    if(flag > x){
      Posts[i] = Posts[i+1];
    }
  }
  if(chave == 0){
    usuario[r].NPosts = usuario[r].NPosts - 1;
  }
}

void MostrarPostsUser(dadosPosts *Posts, dados *usuario, int r, int *NumPosts){
  int i,j,k=0,flag = 0;
  for(i = *NumPosts-1; i>=0;i--){
    for(j = 0; j<usuario[r].NSeguindo; j++){
      if(strcmp(Posts[i].nick,usuario[r].Seguindo[j])==0){
        printf("%s\n", Posts[i].nick);
        printf("%s\n\n", Posts[i].Post);
        k++;
      }
      if(k==4){
        int a;
        printf("VER MAIS? Digite 0 para sim ou 1 para nao: ");
        do{
          setbuf(stdin,NULL);
          scanf("%d", &a);
          if(a!=0 && a!=1){
            printf("INVALIDO. Digite novamente: \n");
          }
        }while(a!=0 && a!=1);
        if(a==0){
          k = 0;
        }
        else{
          flag = 1;
          break;
        }
      }
    }
    if(flag == 1){
      break;
    }
  }
}