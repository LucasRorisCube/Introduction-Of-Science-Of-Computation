#define TAMNOME 40

void menuSLogin();
void menuCLogin(char usuario[TAMNOME]);
