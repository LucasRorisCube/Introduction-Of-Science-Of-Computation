
//inclui as bibliotecas necessarias
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//inclui os cabecalhos
#include "struct.h"
#include "funcoesbd.h"
#include "interface.h"
#include "usuario.h"
#include "post.h"
#include "alocacao.h"

//define tamanho que sera usado com frequencia
#define TAMNOME 40

int main(void) {

  //abre os arquivos usuario e post
  FILE *Usuarios = fopen("Usuarios.txt","a+");
  FILE *ArquivoPosts = fopen("Posts.txt","a+");

  //inicializa (NULL) o ponteiro de postagens
  dadosPosts *Posts = NULL;

  //inicializa (1) o ponteiro numero de usuarios
  int *NumUsuarios = NULL;
  NumUsuarios = realloc(NumUsuarios,sizeof(int));
  VerificarAlocacaoInt(NumUsuarios);

  fseek(Usuarios,0,SEEK_END);
  if(ftell(Usuarios) != 0){
    fseek(Usuarios,0,SEEK_SET);
    fread(NumUsuarios,sizeof(int),1,Usuarios);
  } else {
    fseek(Usuarios,0,SEEK_SET);
    *NumUsuarios = 0;
  }
  fseek(Usuarios,0,SEEK_SET);
  
  //inicializa (1) o ponteiro numero de postagens
  int *NumPosts = NULL;
  NumPosts = realloc(NumPosts,sizeof(int));
  VerificarAlocacaoInt(NumPosts);

  //inicializa (10) o ponteiro que armazena usuarios
  dados *usuario = NULL;
  int *min = 0;
  usuario = realloc(usuario,sizeof(dados)*(*NumUsuarios));

  //busca no arquivo a quantidade de postagens
  fseek(ArquivoPosts,0,SEEK_END);
  *NumPosts = ftell(ArquivoPosts);

  //corrige o valor encontrado, pois o arquivo de postagens armazena também o nome dos usuarios que postaram
  *NumPosts = *NumPosts/(sizeof(char)*40+sizeof(char)*130);

  //realoca o ponteiro de postagens com o numero encontrado
  int k;
  for(k = 0; k<=*NumPosts;k+=10);
  Posts = realloc (Posts, sizeof(dadosPosts)*k);
  VerificarAlocacaoDadosPosts(Posts);

  fseek(ArquivoPosts,0,SEEK_SET);
  //inicializa a struct de usuarios com as
  //informacoes dos arquivos
  Inicializar(NumUsuarios,Usuarios,usuario,ArquivoPosts,Posts,NumPosts);

  system("clear || cls");
  printf("Bem vindo a BlaBla!!!\n\nVamos comecar? \n\n");

  //inicializa um laco que mantem o menu administrador
  int x = 0;
  while(x != 9){

    //chama a interface do menu
    menuSLogin();
    //le  a opcao desejada pelo usuario
    x = 0;
    scanf("%d",&x);
    //zera o buffer de qualquer caracter a mais inserido
    while(getchar() != '\n');
    switch(x){
      case 1:

        //insere o usuario, salva as informacoes nos arquivos, informa ao usuario e limpa a tela

        usuario = realloc(usuario, sizeof(dados)*(*NumUsuarios + 1));

        InserirUsuario(usuario,NumUsuarios, min);

        Salvar(NumUsuarios,Usuarios,usuario,ArquivoPosts,Posts,NumPosts);
        
        
        break;
      
      case 2:

        //remove o usuario, salva as alteracoes nos arquivos, informa ao usuario e limpa a tela
        RemoverUsuario(usuario,NumUsuarios,Posts,NumPosts);
        Salvar(NumUsuarios,Usuarios,usuario,ArquivoPosts,Posts,NumPosts);
        break;
      
      case 3:
        //consulta informacoes de um usuario selecionado
        ConsultarUsuario(usuario,NumUsuarios,NumPosts, Posts);
        system("clear||cls");	
        break;
      
      case 4:

        //pede e le nickname do usuario para login, chama uma funcao que verifica se o login eh valido e mantem um laco enquanto o nickname nao for valido
        printf("\nDigite o nick do login, ou digite -1 para voltar: ");
        int r = -1;
        char login[TAMNOME];
        while(r == -1){
          setbuf(stdin,NULL);
          fgets(login, TAMNOME, stdin);
          if(strcmp(login,"-1\n") == 0){
            break;
          }
          r = VerificarExistencia(login,usuario,NumUsuarios);
          if(r == -1){
            printf("Usuario inexistente. Tente novamente, ou crie um novo usuario.\n");
          }
        }
        if(strcmp(login,"-1\n") != 0){
          //apresenta menu e le a opcao desejada pelo usuario
          system("clear || cls");
          printf("Ola %s\nComo tem sido?\n\n", usuario[r].nick);

          //mantem o laco de menu de usuario ate que ele digite 10
          int y = 0;
          while(y != 10){

            menuCLogin();
            scanf("%d",&y);

            switch(y) {
              case 1:

                //realoca ponteiro de postagens
                if(*NumPosts%10 == 0){
                  Posts = realloc(Posts,sizeof(dadosPosts)*(*NumPosts+10));
                }
                VerificarAlocacaoDadosPosts(Posts);

                //adiciona postagem e salva alteracoes
                AdicionarPost(Posts,NumPosts,usuario,r);
                Salvar(NumUsuarios,Usuarios,usuario,ArquivoPosts,Posts,NumPosts);
                break;
                  
              case 2:

                //remove postagem e salva alteracoes
                RemoverPost(Posts,NumPosts,usuario,r,0,0);
                Salvar(NumUsuarios,Usuarios,usuario,ArquivoPosts,Posts,NumPosts);
                break;
                  
              case 3:

                //segue usuario e salva informacoes
                Seguir(usuario,r,NumUsuarios);
                Salvar(NumUsuarios,Usuarios,usuario,ArquivoPosts,Posts,NumPosts);
                break;
                  
              case 4:

                //se esta seguindo alguem
                if(usuario[r].NSeguindo != 0){
                  //deixa de seguir e salva alteracoes
                  DeixarSeguir(usuario,r,NumUsuarios,0);
                  Salvar(NumUsuarios,Usuarios,usuario,ArquivoPosts,Posts,NumPosts);

                //se nao segue ninguem
                } else {

                  //informa ao usuario
                  printf("Voce nao tem seguidores para essa funcao\n");
                }
                break;
  
              case 5:

                //mostra de cinco em cinco as postagens de quem ta seguindo
                system("clear||cls");
                int flag = 0;
                for(int i = 0;i<usuario[r].NSeguindo;i++){
                  int s = VerificarExistencia(usuario[r].Seguindo[i],usuario,NumUsuarios);
                  if(usuario[s].NPosts != 0){
                    flag = 1;
                  }
                }
                if(flag == 1){
                  MostrarPostsUser(Posts,usuario, r,NumPosts);
                  system("clear||cls");
                } else {
                  printf("Nao ha nenhuma postagem dos seus seguidores\n\n");
                }
                break;
                  
              case 6:

                //lista os seguidores do usuario:
                if(usuario[r].NSeguidores != 0){
                  system("clear||cls");
                  ListarSeguidores(usuario, r);
                  system("clear||cls");
                } else {
                  printf("\nVoce nao tem seguidores! :(\n");
                  printf("\n\nPressione Enter para voltar.");
                  setbuf(stdin,NULL);
                  getc(stdin);
                  system("clear||cls");
                }
                break;
                  
              case 7:

                //lista quem o usuario esta seguindo:
                if(usuario[r].NSeguindo != 0){
                system("clear || cls");
                ListarSeguindo(usuario, r);
                system("clear||cls");
                } else {
                  printf("\nVoce nao esta seguindo ninguem!\n");
                  printf("\n\nPressione Enter para voltar.");
                  setbuf(stdin,NULL);
                  getc(stdin);
                  system("clear||cls");
                }
                break;
                  
              case 8:

                system("clear||cls");
                mostrarPostsAutoria(r, usuario, NumPosts, Posts);
                system("clear||cls");
                break;

              case 9:

                system("clear || cls");
                MostrarInfoUser(usuario,r);
                system("clear||cls");
                break;

              case 10:

                //limpa a tela e quebra o laco menu de usuario 
                system("clear || cls");
                break;

              //trata opcoes invalidas inseridas     
              default:
              
                system("clear||cls");
                printf("\nOpcao invalida! Tente novamente inserindo numeros de 1 a 10.\n\n");
                break;
            }
          }
        } else {
          system("clear||cls");
        }
        break; 
      
      case 5:

        //mostra de cinco em cinco todos os posts da rede
        system("clear || cls");
        MostrarTodosPosts(NumPosts,Posts);
        system("clear||cls");
        break;
      
      case 6:
        system("clear||cls");
        ZerarRedeSocial(Usuarios,ArquivoPosts);
        
        break;

      case 7:

        //lista todos os usuarios e suas informacoes
        if(*NumUsuarios != 0){
          system("clear||cls");
          ListarUsersEInfos(usuario, NumUsuarios);
        } else {
          printf("Nao ha usuarios cadastrados!\n");
          printf("\nPressione Enter para voltar.\n");
          getc(stdin);
        }
        system("clear||cls");
        break;

      case 8:

        //mostra informacoes da rede social
        system("clear||cls");
        MostrarInformacoes(NumUsuarios,Posts,usuario,NumPosts);
        system("clear||cls");
        break;

      case 9:
        //quebra o laco menu inicial
        break;

      //trata opcoes invalidas  
      default:
        system("clear||cls");
        printf("\nOpcao invalida! Tente novamente inserindo numeros de 1 a 9.\n\n");
        break;
    }
  }

  //salva nos arquivos as alteracoes feitas durante
  //o uso do programa
  Salvar(NumUsuarios,Usuarios,usuario,ArquivoPosts,Posts,NumPosts);

  //libera os ponteiros
  Terminar(NumUsuarios,Usuarios,usuario,ArquivoPosts,Posts,NumPosts);
}