#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "struct.h"
//Verificação de ponteiros do tipo int
void VerificarAlocacaoInt(int *ponteiro){
  if(ponteiro == NULL){
    printf("Erro de alocacao(int)\n");
    exit(1);
  }
}

//Verificação de ponteiros do tipo char
void VerificarAlocacaoChar(char *ponteiro){
  if(ponteiro == NULL){
    printf("Erro de alocacao(char)\n");
    exit(1);
  }
}


//Verificação de ponteiros do tipo ponteiro de char
void VerificarAlocacao_Char(char* *ponteiro){
  if(ponteiro == NULL){
    printf("Erro de alocacao(char*)\n");
    exit(1);
  }
}

//Verificação de ponteiros do tipo dados
void VerificarAlocacaoDados(dados *ponteiro){
  if(ponteiro == NULL){
    printf("Erro de alocacao(dados)\n");
    exit(1);
  }
}

//Verificação de ponteiros do tipo dadosPosts
void VerificarAlocacaoDadosPosts(dadosPosts *ponteiro){
  if(ponteiro == NULL){
    printf("Erro de alocacao(dadosPosts)\n");
    exit(1);
  }
}