#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "struct.h"

#define TAMNOME 40

//cria novos posts
void AdicionarPost(dadosPosts *Posts,int *NumPosts,dados *usuario,int r){
  
  //recebe o post
  char temp[140];
  do{  
    printf("\nDigite -1 para voltar ou escreva o que deseja publicar: ");
    setbuf(stdin,NULL);
    fgets(temp,140,stdin);
    //garante que o post não tenha mais que 127 caracteres
    if(strlen(temp) > 130){
      printf("Seu post e grande demais, o tamanho maximo permitido e de 127 caracteres.\n");
      while(getchar() != '\n');
    }
  }while(strlen(temp) > 130);
  
  //publica o post somente se a pessoa não tiver inserido o "-1", que é o comando pra voltar
  if(strcmp(temp,"-1\n")!= 0){
    //nesse ponto, sabe-se que o post é válido. portanto, salva seu corpo no vetor de posts e salva o nick de quem postou.
    strcpy(Posts[*NumPosts].Post,temp);
    strcpy(Posts[*NumPosts].nick,usuario[r].nick);
    //incrementa o número de posts do usuário
    usuario[r].NPosts = usuario[r].NPosts + 1;
    //incrementa o número de posts da rede
    *NumPosts = *NumPosts + 1;
    system("clear||cls");
    printf("\nPublicado!\n\n");
  }
  
  //essa parte é executada se a pessoa optou por sair sem escrever seu post
  else{
    system("clear||cls");
  }
}

//remove posts
void RemoverPost(dadosPosts *Posts,int *NumPosts,dados *usuario,int r,int x,int chave){
  setbuf(stdin,NULL);

  //a chave 0 permite com que a pessoa escolha o post a ser removido
  if(chave == 0){
    int aux = 0;
    //lista os posts da pessoa ordenadamente, para que ela possa escolher qual deseja apagar
    for(int i = 0;i<*NumPosts;i++){
      if(strcmp(usuario[r].nick,Posts[i].nick) == 0){
        printf("%d - %s",aux,Posts[i].Post);
        aux++;
      }
    }
    
    //recebe o número do post que a pessoa deseja excluir
    do{
      printf("\nDigite -1 para voltar ou escolha a postagem que quer excluir.\n");
      scanf("%d",&x);
      //garante que a pessoa não tente excluir um post que não foi mostrado
      if((x<0 && x!= -1) || x>=usuario[r].NPosts){
        printf("Opcao invalida. Tente novamente inserindo numeros de 0 a %d.\n", usuario[r].NPosts-1);
      }
    }while((x<0 && x!= -1) || x>=usuario[r].NPosts);
  }

  //nesse ponto, se x é diferente de -1 (opção de voltar), é um post válido para ser apagado, o que é feito.
  if(x != -1){
    
    //aqui, a flag guarda somente o índice dos posts do usuário logado, enquanto o i guarda o índice desses posts dentro de todo o vetor NumPosts 
    int flag = 0;
    for(int i = 0;i<*NumPosts;i++){
      if(strcmp(usuario[r].nick,Posts[i].nick) == 0){
        flag++;
      }
      //quando flag é maior que x, quer dizer que os posts estão salvos a frente do post a ser apagado. nesse momento, os posts a frente são puxados para trás. assim, o post desejado é apagado e não fica um "buraco" no meio do vetor
      if(flag > x){
        Posts[i] = Posts[i+1];
      }
    }
    //decrementa o número de posts do usuário
    usuario[r].NPosts--;
    //decrementa o número de posts da rede
    *NumPosts = *NumPosts - 1;
    system("clear||cls");
    printf("\nPublicacao apagada!\n\n");
  }
  else{
    system("clear|| cls");
  }
}

//mostra os posts para os usuário logado, das pessoas que ele segue
void MostrarPostsUser(dadosPosts *Posts, dados *usuario, int r, int *NumPosts){
  int i;
  int j;
  int k=0;
  int flag = 0;
  
  //nesse momento o i vai de NumPosts a 0, para mostrar os posts por ordem cronológica, do mais recente para o mais antigo
  for(i = *NumPosts-1; i>=0;i--){
    
    //percorre os usuários que r segue e printa os posts mais recentes (devido ao controle cronológico do i), de 5 em 5, com controle no k, que varia de 0 a 4.	  
    for(j = 0; j<usuario[r].NSeguindo; j++){
      if(strcmp(Posts[i].nick,usuario[r].Seguindo[j])==0){
        printf("Postado por: %s", Posts[i].nick);
        printf("Post: %s\n", Posts[i].Post);
        k++;
      }
      
      //pergunta se o usuário deseja ver mais 5 posts, até que ele insira um número válido (0 ou 1)
      if(k==5){
        int a;
        printf("Deseja ver mais? Digite 0 para sim ou 1 para nao. Em seguida, pressione Enter\n\n");
        do{
          setbuf(stdin,NULL);
          scanf("%d", &a);
          if(a!=0 && a!=1){
            printf("Opcao invalida. Tente novamente inserido o numero 0 ou 1.\n\n");
          }
        }while(a!=0 && a!=1);
        
	//caso o usuário deseje ver mais, zera o k e printa mais 5 posts
	if(a==0){
          k = 0;
        }

	//se o usuário não deseja ver mais posts, levanta a flag e sai do laço
        else{
          flag = 1;
          break;
        }
      }
    }
    //quando a flag levanta, o usuário não quer mais ver posts. portanto, quebra o laço que printa os posts e sai da função
    if(flag == 1){
      break;
    }
  }
  printf("Pressione Enter para voltar.\n");
  setbuf(stdin,NULL);
  getc(stdin);
  system("clear||cls");
}

//printa todos os posts da rede
void MostrarTodosPosts(int *NumPosts,dadosPosts *Posts){
  int i;
  int k = 0;
  int flag = 0;
  printf("POSTS:\n\n");
  
  //o i segue a lógica da ordem cronológica das postagens. para tanto, é inicializado como sendo NumPosts-1 e é decrementado até 0, quando posta o último post.
  for(i = *NumPosts-1; (i>=0) && (!flag); i--){
    printf("Postado por: %s", Posts[i].nick);
    printf("%s\n", Posts[i].Post);
    k++;

    //aqui novamente, o k, variando de 0 a 4, funciona para que os posts sejam printados de 5 em 5.
    if(k==4){
      int a;
      printf("Deseja ver mais? Digite 0 para sim ou 1 para nao. Em seguida, pressione Enter.\n\n");
      do{
        setbuf(stdin,NULL);
        scanf("%d", &a);
       if(a!=0 && a!=1){
          printf("Opção inválida! Tente novamente inserindo 0 ou 1.\n\n");
        }
      }while(a!=0 && a!=1);
      
      //se a pessoa escolher 0, printa mais 5 posts e pergunta novamente se deseja ver mais. caso contrário, finaliza a função.
      if(a==0){
        k = 0;
      }
      else{
    	flag = 1;
      }
    }
  }
  printf("\nPressione Enter para voltar.");
  setbuf(stdin,NULL);
  getc(stdin);
}

//mostra os posts de um usuário
void mostrarPostsAutoria(int r, dados *usuario, int *NumPosts, dadosPosts *Posts) {
  int i = 0;
  int cont = 0;

  //se o número de posts do usuário é 0, quer dizer que ele não tem publicações e não há o que printar.
  if(usuario[r].NPosts == 0){
    printf("\nNao ha publicacoes.\n\n");
  }
  else{

    //percorre de i ao número de posts do usuário, printando todos de 5 em 5  
    for(i = 0; i < *NumPosts; i++) {
      if(strcmp(Posts[i].nick,usuario[r].nick)==0) {
        printf("\nPost %d:\n%s", cont, Posts[i].Post);
        cont++;

	//aqui, o cont que controla para que seja printado de 5 em 5 posts. Portanto, quando ele é múltiplo de 5, o programa pergunta ao usuário se ele deseja ver mais posts. 
        if((cont % 5) == 0){
          int a;
          printf("\nDeseja ver mais posts? Digite 0 para sim ou 1 para não. Em seguida, pressione Enter.\n\n");
          do{
            setbuf(stdin,NULL);
            scanf("%d", &a);
          if(a!=0 && a!=1){
              printf("Opção inválida! Tente novamente inserindo 0 ou 1.\n\n");
            }
          }while(a!=0 && a!=1);
          if(a==0){

          }
          else{
            break;
          }
        }
      }
    }
  }
  printf("\nPressione Enter para voltar.");
  setbuf(stdin,NULL);
  getc(stdin);
}
